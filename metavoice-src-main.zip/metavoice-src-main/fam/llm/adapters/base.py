from abc import ABC


class BaseDataAdapter(ABC):
    pass
