from fam.llm.mixins.causal import CausalInferenceMixin
from fam.llm.mixins.non_causal import NonCausalInferenceMixin
